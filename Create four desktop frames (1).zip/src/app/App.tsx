import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import { Login } from './components/login';
import { StudentMenu } from './components/student-menu';
import { OrderConfirmation } from './components/order-confirmation';
import { CanteenDashboard } from './components/canteen-dashboard';
import { RFIDPayment } from './components/rfid-payment';

export interface CartItem {
  item: MenuItem;
  quantity: number;
}

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  available: boolean;
}

export interface OrderData {
  orderId: string;
  cart: CartItem[];
  totalPrice: number;
  paymentStatus: 'pending' | 'paid';
  estimatedTime: number;
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [studentId, setStudentId] = useState('');
  const [walletBalance, setWalletBalance] = useState(500);
  const [currentView, setCurrentView] = useState<'menu' | 'confirm' | 'order-details' | 'dashboard'>('menu');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentOrder, setCurrentOrder] = useState<OrderData | null>(null);

  const handleLogin = (id: string) => {
    setStudentId(id);
    setIsLoggedIn(true);
    setWalletBalance(500); // Demo wallet balance
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setStudentId('');
    setWalletBalance(500);
    setCurrentView('menu');
    setCart([]);
    setCurrentOrder(null);
  };

  const handleConfirmOrder = (orderData: OrderData) => {
    // Deduct from wallet
    setWalletBalance(prev => prev - orderData.totalPrice);
    setCurrentOrder(orderData);
    setCurrentView('order-details');
    setCart([]);
  };

  const handlePayWithRFID = () => {
    if (currentOrder) {
      setCurrentOrder({
        ...currentOrder,
        paymentStatus: 'paid'
      });
    }
  };

  const handleNewOrder = () => {
    setCurrentOrder(null);
    setCurrentView('menu');
  };

  if (!isLoggedIn) {
    return (
      <>
        <Login onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  return (
    <>
      {currentView === 'menu' && (
        <StudentMenu
          studentId={studentId}
          walletBalance={walletBalance}
          cart={cart}
          setCart={setCart}
          onViewChange={setCurrentView}
          onLogout={handleLogout}
        />
      )}
      {currentView === 'confirm' && (
        <OrderConfirmation
          cart={cart}
          walletBalance={walletBalance}
          onConfirmOrder={handleConfirmOrder}
          onBack={() => setCurrentView('menu')}
        />
      )}
      {currentView === 'order-details' && currentOrder && (
        <RFIDPayment
          order={currentOrder}
          walletBalance={walletBalance}
          onPayWithRFID={handlePayWithRFID}
          onNewOrder={handleNewOrder}
        />
      )}
      {currentView === 'dashboard' && (
        <CanteenDashboard onBack={() => setCurrentView('menu')} />
      )}
      <Toaster />
    </>
  );
}
