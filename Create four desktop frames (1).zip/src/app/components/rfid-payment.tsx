import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { CheckCircle, Clock, Radio, Wallet, Package, ArrowLeft } from "lucide-react";
import { OrderData } from "../App";
import { toast } from "sonner";

interface RFIDPaymentProps {
  order: OrderData;
  walletBalance: number;
  onPayWithRFID: () => void;
  onNewOrder: () => void;
}

export function RFIDPayment({ order, walletBalance, onPayWithRFID, onNewOrder }: RFIDPaymentProps) {
  const isPaid = order.paymentStatus === 'paid';

  const handleTapRFID = () => {
    onPayWithRFID();
    toast.success("Payment successful! Order is being prepared.");
  };

  const formatTime = (minutes: number) => {
    return `${minutes} minutes`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <h1 className="text-2xl font-bold text-gray-900">Order Details</h1>
            <Button variant="outline" onClick={onNewOrder}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Menu
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Status Banner */}
        <div className="text-center mb-8">
          {isPaid ? (
            <>
              <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
                <CheckCircle className="h-12 w-12 text-green-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Confirmed!</h1>
              <Badge className="bg-green-600 text-lg px-4 py-1">Paid & Preparing</Badge>
              <p className="text-gray-600 mt-2">Your meal is being prepared</p>
            </>
          ) : (
            <>
              <div className="inline-flex items-center justify-center w-20 h-20 bg-orange-100 rounded-full mb-4">
                <Clock className="h-12 w-12 text-orange-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Created</h1>
              <Badge variant="secondary" className="text-lg px-4 py-1">Payment Pending</Badge>
              <p className="text-gray-600 mt-2">Complete payment to start preparation</p>
            </>
          )}
        </div>

        {/* Key Information Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Order ID */}
          <Card>
            <CardContent className="pt-6 text-center">
              <Package className="h-6 w-6 mx-auto mb-2 text-blue-600" />
              <p className="text-sm text-gray-600 mb-1">Order ID</p>
              <p className="text-2xl font-bold text-blue-600">{order.orderId}</p>
            </CardContent>
          </Card>

          {/* Estimated Time */}
          <Card>
            <CardContent className="pt-6 text-center">
              <Clock className="h-6 w-6 mx-auto mb-2 text-purple-600" />
              <p className="text-sm text-gray-600 mb-1">Prep Time</p>
              <p className="text-2xl font-bold">{formatTime(order.estimatedTime)}</p>
            </CardContent>
          </Card>

          {/* Wallet Balance */}
          <Card>
            <CardContent className="pt-6 text-center">
              <Wallet className="h-6 w-6 mx-auto mb-2 text-green-600" />
              <p className="text-sm text-gray-600 mb-1">Remaining Balance</p>
              <p className="text-2xl font-bold text-green-600">₹{walletBalance.toFixed(2)}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Order Details */}
          <Card>
            <CardHeader>
              <CardTitle>Ordered Items</CardTitle>
              <CardDescription>Your food items</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {order.cart.map((cartItem) => (
                  <div key={cartItem.item.id} className="flex justify-between items-start pb-3 border-b">
                    <div className="flex-1">
                      <p className="font-medium">{cartItem.item.name}</p>
                      <p className="text-sm text-gray-600">Quantity: {cartItem.quantity}</p>
                    </div>
                    <p className="font-medium">
                      ₹{(cartItem.item.price * cartItem.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal:</span>
                  <span>₹{order.totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Service Fee:</span>
                  <span>₹0.00</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t">
                  <span>Total Amount:</span>
                  <span className="text-orange-600">₹{order.totalPrice.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Section */}
          <Card className={isPaid ? "border-green-200 bg-green-50" : "border-orange-200 bg-orange-50"}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Radio className="h-5 w-5" />
                Payment Status
              </CardTitle>
              <CardDescription>
                {isPaid ? "Payment completed successfully" : "Tap your RFID card to pay"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* RFID Visual */}
              <div className="relative">
                <div className={`w-full aspect-square rounded-lg flex items-center justify-center border-4 border-dashed ${
                  isPaid ? "bg-gradient-to-br from-green-50 to-green-100 border-green-300" : "bg-gradient-to-br from-orange-50 to-orange-100 border-orange-300"
                }`}>
                  <div className={`w-32 h-48 bg-white rounded-lg shadow-lg flex items-center justify-center ${
                    isPaid ? "scale-110" : ""
                  }`}>
                    <Radio className={`h-16 w-16 ${
                      isPaid ? "text-green-500" : "text-orange-500"
                    }`} />
                  </div>
                </div>
              </div>

              {/* Payment Info */}
              <div className={`space-y-3 p-4 rounded-lg border ${
                isPaid ? "bg-green-100 border-green-200" : "bg-white border-gray-200"
              }`}>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-700">Order Amount:</span>
                  <span className="font-semibold">₹{order.totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-700">Payment Method:</span>
                  <span className="font-semibold">RFID Card</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-700">Status:</span>
                  <Badge variant={isPaid ? "default" : "secondary"} className={isPaid ? "bg-green-600" : ""}>
                    {isPaid ? "Paid" : "Pending"}
                  </Badge>
                </div>
              </div>

              {/* Action Button */}
              {!isPaid && (
                <Button onClick={handleTapRFID} className="w-full" size="lg">
                  <Radio className="h-5 w-5 mr-2" />
                  Tap RFID to Pay
                </Button>
              )}

              {isPaid && (
                <div className="text-center">
                  <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-600" />
                  <p className="font-semibold text-green-700">Payment Successful</p>
                  <p className="text-sm text-green-600 mt-1">Your order is being prepared</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Pickup Instructions */}
        {isPaid && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Pickup Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-gray-900 min-w-6">1.</span>
                  <span>Wait for approximately {order.estimatedTime} minutes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-gray-900 min-w-6">2.</span>
                  <span>Show your order ID ({order.orderId}) at the counter</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-gray-900 min-w-6">3.</span>
                  <span>Present your student ID for verification</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-semibold text-gray-900 min-w-6">4.</span>
                  <span>Collect your order and enjoy your meal!</span>
                </li>
              </ol>
            </CardContent>
          </Card>
        )}

        {/* New Order Button */}
        {isPaid && (
          <div className="flex justify-center mt-8">
            <Button onClick={onNewOrder} size="lg">
              Place New Order
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
