import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ShoppingCart, Plus, Search, UtensilsCrossed, Wallet, LogOut } from "lucide-react";
import { Input } from "./ui/input";
import { CartModal } from "./cart-modal";
import { CartItem, MenuItem } from "../App";

interface StudentMenuProps {
  studentId: string;
  walletBalance: number;
  cart: CartItem[];
  setCart: (cart: CartItem[]) => void;
  onViewChange: (view: 'menu' | 'confirm' | 'order-details' | 'dashboard') => void;
  onLogout: () => void;
}

const menuItems: MenuItem[] = [
  {
    id: 1,
    name: "Classic Pizza",
    description: "Fresh tomato sauce, mozzarella, and basil",
    price: 120,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1682989087146-70a0834c42c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMHNsaWNlJTIwbWVhbHxlbnwxfHx8fDE3NzA3MDA0MTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    available: true,
  },
  {
    id: 2,
    name: "Burger & Fries",
    description: "Beef patty with lettuce, tomato, and crispy fries",
    price: 150,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1651843465180-5965076f7368?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXJnZXIlMjBmcmllcyUyMG1lYWx8ZW58MXx8fHwxNzcwNjgzODE2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    available: true,
  },
  {
    id: 3,
    name: "Pasta Bowl",
    description: "Penne pasta with creamy sauce and parmesan",
    price: 130,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1635475556713-8d3ff880d9ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXN0YSUyMGJvd2wlMjBtZWFsfGVufDF8fHx8MTc3MDcwMDQxMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    available: true,
  },
  {
    id: 4,
    name: "Fresh Salad Bowl",
    description: "Mixed greens, cherry tomatoes, cucumber, and vinaigrette",
    price: 80,
    category: "Salads",
    image: "https://images.unsplash.com/photo-1649531794884-b8bb1de72e68?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWxhZCUyMGJvd2wlMjBoZWFsdGh5fGVufDF8fHx8MTc3MDY1MzQ2OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    available: true,
  },
  {
    id: 5,
    name: "Fresh Sandwich",
    description: "Turkey, cheese, lettuce, tomato on whole grain bread",
    price: 90,
    category: "Sandwiches",
    image: "https://images.unsplash.com/photo-1763647814142-b1eb054d42f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW5kd2ljaCUyMGZyZXNoJTIwbWVhbHxlbnwxfHx8fDE3NzA2MzA3MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    available: true,
  },
  {
    id: 6,
    name: "Caesar Salad",
    description: "Romaine lettuce, croutons, parmesan, Caesar dressing",
    price: 100,
    category: "Salads",
    image: "https://images.unsplash.com/photo-1649531794884-b8bb1de72e68?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWxhZCUyMGJvd2wlMjBoZWFsdGh5fGVufDF8fHx8MTc3MDY1MzQ2OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    available: false,
  },
];

export function StudentMenu({ studentId, walletBalance, cart, setCart, onViewChange, onLogout }: StudentMenuProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [isCartModalOpen, setIsCartModalOpen] = useState(false);

  const addToCart = (item: MenuItem) => {
    setCart([...cart].map((c) => {
      const existing = cart.find((c) => c.item.id === item.id);
      if (existing) {
        return cart.map((c) =>
          c.item.id === item.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return cart;
    }).flat());
    
    const existing = cart.find((c) => c.item.id === item.id);
    if (!existing) {
      setCart([...cart, { item, quantity: 1 }]);
    } else {
      setCart(cart.map((c) =>
        c.item.id === item.id ? { ...c, quantity: c.quantity + 1 } : c
      ));
    }
    
    // Show cart modal when item is added
    setIsCartModalOpen(true);
  };

  const updateQuantity = (itemId: number, change: number) => {
    const updated = cart
      .map((c) => {
        if (c.item.id === itemId) {
          const newQuantity = c.quantity + change;
          return { ...c, quantity: newQuantity };
        }
        return c;
      })
      .filter((c) => c.quantity > 0);
    setCart(updated);
  };

  const totalPrice = cart.reduce((sum, c) => sum + c.item.price * c.quantity, 0);
  const totalItems = cart.reduce((sum, c) => sum + c.quantity, 0);

  const filteredItems = menuItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "all" || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ["all", ...Array.from(new Set(menuItems.map((item) => item.category)))];

  const handleProceedToConfirm = () => {
    if (cart.length > 0) {
      setIsCartModalOpen(false);
      onViewChange('confirm');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <UtensilsCrossed className="h-6 w-6 text-orange-600" />
              <h1 className="text-2xl font-bold text-gray-900">SmartQ Campus</h1>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg">
                <Wallet className="h-4 w-4 text-green-600" />
                <span className="font-semibold text-green-700">₹{walletBalance.toFixed(2)}</span>
              </div>
              <Badge variant="outline" className="text-sm">
                {studentId}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onViewChange('dashboard')}
              >
                Admin Dashboard
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onLogout}
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Today's Menu</h2>
            <p className="text-gray-600 mt-1">Select items to add to your cart</p>
          </div>
          <Button
            onClick={() => setIsCartModalOpen(true)}
            className="relative"
            size="lg"
          >
            <ShoppingCart className="h-5 w-5 mr-2" />
            View Cart
            {totalItems > 0 && (
              <Badge className="absolute -top-2 -right-2 h-6 w-6 flex items-center justify-center p-0 bg-red-500">
                {totalItems}
              </Badge>
            )}
          </Button>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              type="text"
              placeholder="Search menu items..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <Tabs defaultValue="all" className="mb-6" onValueChange={setActiveCategory}>
          <TabsList>
            {categories.map((category) => (
              <TabsTrigger key={category} value={category} className="capitalize">
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className={!item.available ? "opacity-50" : ""}>
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{item.name}</CardTitle>
                    <CardDescription>{item.description}</CardDescription>
                  </div>
                  <Badge variant={item.available ? "default" : "secondary"}>
                    {item.available ? "Available" : "Sold Out"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-orange-600">
                    ₹{item.price.toFixed(2)}
                  </span>
                  <Button
                    onClick={() => addToCart(item)}
                    disabled={!item.available}
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <CartModal
        isOpen={isCartModalOpen}
        onClose={() => setIsCartModalOpen(false)}
        cart={cart}
        onUpdateQuantity={updateQuantity}
        onProceedToConfirm={handleProceedToConfirm}
      />
    </div>
  );
}