import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "./ui/dialog";
import { ShoppingCart, Plus, Minus, X } from "lucide-react";
import { CartItem } from "../App";

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (itemId: number, change: number) => void;
  onProceedToConfirm: () => void;
}

export function CartModal({ isOpen, onClose, cart, onUpdateQuantity, onProceedToConfirm }: CartModalProps) {
  const totalPrice = cart.reduce((sum, c) => sum + c.item.price * c.quantity, 0);
  const totalItems = cart.reduce((sum, c) => sum + c.quantity, 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Your Cart ({totalItems} items)
          </DialogTitle>
          <DialogDescription>
            Review your order before proceeding
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 max-h-[400px] overflow-y-auto py-4">
          {cart.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <ShoppingCart className="h-12 w-12 mx-auto mb-2 opacity-30" />
              <p>Your cart is empty</p>
            </div>
          ) : (
            <>
              {cart.map((cartItem) => (
                <div
                  key={cartItem.item.id}
                  className="flex justify-between items-start gap-3 pb-4 border-b"
                >
                  <div className="flex-1">
                    <p className="font-medium">{cartItem.item.name}</p>
                    <p className="text-sm text-gray-600">
                      ₹{cartItem.item.price.toFixed(2)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onUpdateQuantity(cartItem.item.id, -1)}
                      className="h-8 w-8 p-0"
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-8 text-center font-medium">{cartItem.quantity}</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onUpdateQuantity(cartItem.item.id, 1)}
                      className="h-8 w-8 p-0"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="text-right min-w-[80px]">
                    <p className="font-semibold">
                      ₹{(cartItem.item.price * cartItem.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}

              <div className="flex justify-between items-center text-lg font-bold pt-2 border-t">
                <span>Total:</span>
                <span className="text-orange-600">₹{totalPrice.toFixed(2)}</span>
              </div>
            </>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Continue Ordering
          </Button>
          <Button
            onClick={onProceedToConfirm}
            disabled={cart.length === 0}
            className="flex-1"
          >
            Proceed to Confirm
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
